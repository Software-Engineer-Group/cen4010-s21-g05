<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<link rel="stylesheet" type="text/css" href="css/series.css">

<div class="limiter">
		<div class="redbackground" style="background-image: url('images/red.jpg');">

<div class="container bootstrap snippets bootdey">
    <div class="profile card">
        <div class="profile-body">
            <div class="profile-bio">
                <div class="row">
                    <div class="col-md-5 text-center">
                        <img class="img-thumbnail md-margin-bottom-10" src="images/jurassic.jpg" alt="series photo">
                    </div>

                        <div class="col-md-7">  
                           <h3>Jurassic Park</h3>
                            <hr>
                            <p>Wealthy businessman John Hammond and a team of genetic scientists have created a wildlife park of de-extinct dinosaurs.
                            When industrial sabotage leads to a catastrophic shutdown of the park's power facilities and security precautions, a small group of visitors and Hammond's grandchildren struggle to survive and escape the perilous island.</p>                           <hr>
                            <br>
                            <br>
                        
                            <a class="nav-link btn-outline-primary rounded-pill px-3" style="margin: top -100px;"  href="discussion.php">Discussion</a>
                     </div>
                  </div>    
               </div>
        	</div>
              <div class="iframe-container">
              <iframe width="560" height="315" src="https://www.youtube.com/embed/lc0UehYemQA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>            </div>
        </div>
     </div>   
    </div>
</div>                             