<?php
session_start();

include("connection.php");
include("functions.php");
$user_data = check_login($con);

?>

<!DOCTYPE html>
<html>

<head>
    <title>Chatflix</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="assets/img/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <!-- Load Require CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font CSS -->
    <link href="assets/css/boxicon.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Load Tempalte CSS -->
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="css/discussion.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>

    <?php include("navbar.php");?>

    <br><br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="wrapper wrapper-content animated fadeInRight">

                    <div class="ibox-content m-b-sm border-bottom">
                        <div class="p-xs">
                            <div class="pull-left m-r-md">
                            </div>
                            <h2>Chatflix Forums</h2>
                        </div>
                    </div>

                    <div class="ibox-content forum-container">

                        <div class="forum-title">
                            <div class="pull-right forum-desc">
                                <samll>Total posts: 320,800</samll>
                            </div>
                            <h3>Other subjects</h3>
                        </div>

                        <div class="forum-item">
                            <div class="row">

                                <?php
                        include("connection.php");
                        $gid = $_GET['gid'];
                        $sql = "SELECT gid FROM discgenre WHERE gid ='".$gid."' LIMIT 1";
                        $res = mysqli_query($con,$sql) or die(mysqli_error($con));
                        if (mysqli_num_rows($res) == 1) 
                        {
                            $sql2 = "SELECT * FROM discThread WHERE gid ='".$gid."' ORDER BY threadTopic ASC";
                            $res2 = mysqli_query($con,$sql2) or die(mysqli_error($con));
                            if (mysqli_num_rows($res2) > 0) 
                            {
                                $thread = "";
                                while($row = mysqli_fetch_assoc($res2))
                                {
                                    $threadId = $row['threadId'];
                                    $threadTopic = $row['threadTopic'];
                                    $threadContent = $row['threadContent'];
                                    $thread .= "<a href='view_discPost.php?gid=".$gid."&threadId=".$threadId."'>$threadTopic</a>";
                                }
                                echo "$thread";
                            }
                            else
                            {
                                echo "<a href='index.php'> Return to Forum Index</a><hr/>";
                                echo "<p>There are no threads in this genre yet.</p>";
                            }
                        }
                        else{
                            echo "<a href='index.php'> Return to Forum Index</a><hr/>";
                            echo "<p> You are trying to view a category that does not exist</p>";
                        }
                        ?>



                            </div>
                        </div>
                        <div class="row">
                            <?php echo "<a href='create_thread.php?gid=".$gid."'>Click here to make a new thread"; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Templatemo -->
    <script src="assets/js/templatemo.js"></script>
    <!-- Custom -->
    <script src="assets/js/custom.js"></script>

</body>

</html>
