<?php
session_start();

include("connection.php");
include("functions.php");
$user_data = check_login($con);

if(isset($_POST['thread_submit'])){
    if(($_POST['discThread'] == "") && ($_POST['discContent']) == ""){
        echo "Did not fill in both fields";
        exit();
    }
    else{
        $gid = $_POST['gid'];
        $threadTitle = $_POST['discThread'];
        $threadKeys = $_POST['discKeys'];
        $threadContent = $_POST['discContent'];
        $creator = $_SESSION['user_id'];
        
        $sql = "INSERT INTO `discthread`(`threadTopic`, `gid`, `threadKeyword`, `threadContent`, `userId`) VALUES ('$threadTitle','$gid','$threadKeys','$threadContent','$creator')";
        $res = mysqli_query($con,$sql) or die(mysqli_error($con));
        $new_thread_id = mysqli_insert_id($con);
        
        $sql2 = "INSERT INTO discPost (gid, threadId, postCont, userName) VALUES ('".$gid."','".$new_thread_id."','".$threadContent."','".$creator."')";
        $res2 = mysqli_query($con,$sql2) or die(mysqli_error($con));
        
        if(($res) && ($res2)){
            header("Location: view_discThread.php?gid=".$gid."&threadId=".$new_thread_id);
        }
        else{
            echo "There was a problem creating your topic";
        }
    }
}

?>