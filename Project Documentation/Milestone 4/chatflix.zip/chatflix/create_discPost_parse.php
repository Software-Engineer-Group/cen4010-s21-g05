<?php
session_start();

include("connection.php");
include("functions.php");
$user_data = check_login($con);

if(isset($_POST['reply_submit'])){
    
        $gid = $_POST['gid'];
        $threadId = $_POST['threadId'];
        $postCont = $_POST['postCont'];
        $creator = $_SESSION['user_id'];
        
        $sql = "INSERT INTO `discPost`(`threadId`, `gid`, `userName`, `postCont`) VALUES ('$threadId','$gid','$creator','$postCont')";
        $res = mysqli_query($con,$sql) or die(mysqli_error($con));
        
        
        if($res){
            echo "<p>Your reply was successfully posted. <a href='view_topic.php?gid=".$gid."&threadId=".$threadId."'>Click here to return to the topic.</a></p>";
        }
        else{
            echo "There was a problem creating your reply";
        }
}


?>
