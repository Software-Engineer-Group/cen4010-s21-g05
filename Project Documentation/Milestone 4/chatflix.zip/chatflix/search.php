<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<style type="text/css">

	form {
	margin:25%;
	}

</style>
	
	
<body> 
	<form action="result.php" method="get"> 

		<input type="text" name="user_query" size="80" placeholder="Search for Movie or TV Show"/> 
		<input type="submit" name="search" value="Search">		
	
	</form>


</body>
</html>