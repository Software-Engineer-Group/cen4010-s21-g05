-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 06, 2021 at 03:30 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatflix_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bloguser`
--

CREATE TABLE `bloguser` (
  `avatar_id` int(11) NOT NULL,
  `fullName` varchar(20) DEFAULT NULL,
  `dateJoined` varchar(10) DEFAULT NULL,
  `userEmail` varchar(25) NOT NULL,
  `activityStatus` int(11) DEFAULT NULL,
  `privacySet` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `defaultuser`
--

CREATE TABLE `defaultuser` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `defaultuser`
--

INSERT INTO `defaultuser` (`id`, `user_id`, `user_name`, `password`, `date`) VALUES
(1, 235125794241, 'jabdool2016', 'abdool22', '2021-04-06 05:23:01');

-- --------------------------------------------------------

--
-- Table structure for table `discpost`
--

CREATE TABLE `discpost` (
  `postId` int(11) NOT NULL,
  `threadId` int(11) NOT NULL,
  `avatar_id` int(11) NOT NULL,
  `userName` varchar(20) NOT NULL,
  `postCont` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `discthread`
--

CREATE TABLE `discthread` (
  `threadId` int(11) NOT NULL,
  `threadTopic` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `friendlist`
--

CREATE TABLE `friendlist` (
  `user_id` int(11) NOT NULL,
  `avatar_id` int(11) NOT NULL,
  `userName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `moduser`
--

CREATE TABLE `moduser` (
  `id` int(11) NOT NULL,
  `completed` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `seriespg`
--

CREATE TABLE `seriespg` (
  `seriesId` int(11) NOT NULL,
  `seriesSeasons` int(11) DEFAULT NULL,
  `seriesImg` int(11) NOT NULL,
  `seriesName` varchar(20) NOT NULL,
  `seriesBio` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bloguser`
--
ALTER TABLE `bloguser`
  ADD UNIQUE KEY `avatarId` (`avatar_id`);

--
-- Indexes for table `defaultuser`
--
ALTER TABLE `defaultuser`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_name` (`user_name`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `date` (`date`) USING BTREE;

--
-- Indexes for table `discpost`
--
ALTER TABLE `discpost`
  ADD PRIMARY KEY (`postId`),
  ADD KEY `threadId` (`threadId`),
  ADD KEY `avatar_id` (`avatar_id`),
  ADD KEY `userName` (`userName`);

--
-- Indexes for table `discthread`
--
ALTER TABLE `discthread`
  ADD PRIMARY KEY (`threadId`);

--
-- Indexes for table `friendlist`
--
ALTER TABLE `friendlist`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `avatar_id` (`avatar_id`),
  ADD KEY `userName` (`userName`);

--
-- Indexes for table `moduser`
--
ALTER TABLE `moduser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seriespg`
--
ALTER TABLE `seriespg`
  ADD PRIMARY KEY (`seriesId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `defaultuser`
--
ALTER TABLE `defaultuser`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `friendlist`
--
ALTER TABLE `friendlist`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `moduser`
--
ALTER TABLE `moduser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `discpost`
--
ALTER TABLE `discpost`
  ADD CONSTRAINT `discpost_ibfk_1` FOREIGN KEY (`threadId`) REFERENCES `discthread` (`threadId`),
  ADD CONSTRAINT `discpost_ibfk_2` FOREIGN KEY (`avatar_id`) REFERENCES `bloguser` (`avatar_id`),
  ADD CONSTRAINT `discpost_ibfk_3` FOREIGN KEY (`userName`) REFERENCES `defaultuser` (`user_name`);

--
-- Constraints for table `friendlist`
--
ALTER TABLE `friendlist`
  ADD CONSTRAINT `friendlist_ibfk_1` FOREIGN KEY (`avatar_id`) REFERENCES `bloguser` (`avatar_id`),
  ADD CONSTRAINT `friendlist_ibfk_2` FOREIGN KEY (`userName`) REFERENCES `defaultuser` (`user_name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
