-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 07, 2021 at 09:20 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatflix_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `defaultuser`
--

CREATE TABLE `defaultuser` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `avatar_id` int(11) DEFAULT NULL,
  `fullName` varchar(20) DEFAULT NULL,
  `dateJoined` varchar(10) DEFAULT NULL,
  `userEmail` varchar(25) DEFAULT NULL,
  `activityStatus` int(11) DEFAULT NULL,
  `privacySet` int(11) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `defaultuser`
--

INSERT INTO `defaultuser` (`id`, `user_id`, `user_name`, `password`, `avatar_id`, `fullName`, `dateJoined`, `userEmail`, `activityStatus`, `privacySet`, `date`) VALUES
(1, 235125794241, 'jabdool2016', 'abdool22', 0, '', NULL, '', NULL, NULL, '2021-04-07 18:15:15'),
(6, 8605086619, 'test123', '123', 3, 'wefewfwe', '', 'wefwefwe', 0, 0, '2021-04-07 19:18:53'),
(7, 0, '', '', NULL, '', NULL, NULL, NULL, NULL, '2021-04-07 17:28:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `defaultuser`
--
ALTER TABLE `defaultuser`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_name` (`user_name`),
  ADD UNIQUE KEY `avatarId` (`avatar_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `date` (`date`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `defaultuser`
--
ALTER TABLE `defaultuser`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
