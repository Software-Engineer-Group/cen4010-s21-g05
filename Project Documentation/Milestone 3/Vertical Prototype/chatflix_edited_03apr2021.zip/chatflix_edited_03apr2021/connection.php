<?php

$dbhost = "localhost";
$dbuser = "cen4010_s21_g05";
$dbpass = "sure97decimal24";
$dbname = "cen4010_s21_g05";

if(!$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname))
{
    die("failed to connect!");
};

