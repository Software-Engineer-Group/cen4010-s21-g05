<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<link rel="stylesheet" type="text/css" href="css/series.css">

<div class="limiter">
		<div class="redbackground" style="background-image: url('images/red.jpg');">

<div class="container bootstrap snippets bootdey">
    <div class="profile card">
        <div class="profile-body">
            <div class="profile-bio">
                <div class="row">
                    <div class="col-md-5 text-center">
                        <img class="img-thumbnail md-margin-bottom-10" src="images/parks.jpg" alt="series photo">
                    </div>

                        <div class="col-md-7">  
                           <h3>Parks and Recreation</h3>
                            <hr>
                            <p>For years Leslie Knope has labored as a small-town, mid-level bureaucrat in the Parks and Recreation department of Pawnee, Ind.
                        It’s a lowly station for one who once held hopes of becoming the country’s first female president. But does that dampen her enthusiasm? Hardly.
                        </p>                           <hr>
                            <a class="nav-link btn-outline-primary rounded-pill px-3" style="margin: top -100px;"  href="discussion.php">Discussion</a>
                     </div>
                  </div>    
               </div>
        	</div>
              <div class="iframe-container">
              <iframe width="560" height="315" src="https://www.youtube.com/embed/5IZWeAwdJ-s" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>            </div>
        </div>
     </div>   
    </div>
</div>                             