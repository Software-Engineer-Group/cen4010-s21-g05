<?php
session_start();

include("connection.php");
include("functions.php");
include("navbar.php");
$user_data = check_login($con);

if(isset($_POST['update']))
{
    
   $hostname = "localhost";
   $username = "root";
   $password = "";
   $databaseName = "login_sample_db";
   
   $connect = mysqli_connect($hostname, $username, $password, $databaseName);
   
   // get values form input text and number
   
    $id = $_SESSION['user_id'];
    if($_POST['fullName'] == '')
    {
        $fname = $user_data['fullName'];
    }
    else 
        $fname = $_POST['fullName'];

    if($_POST['userEmail'] == '')
    {
        $userEmail = $user_data['userEmail'];
    }
    else 
        $userEmail = $_POST['userEmail'];
    
    if($_POST['userBio'] == '')
    {
        $userBio = $user_data['userBio'];
    }
        else $userBio  = addslashes($_POST['userBio']);
    
   // mysql query to Update data
   $query = "UPDATE `defaultuser` SET `fullName`='$fname',`userEmail`='$userEmail', 
  `userBio`='$userBio'  WHERE `user_id` = $id";
   
   $result = mysqli_query($connect, $query);
   
   if($result)
   {
       //echo 'Data Updated';
       header("Location: profile.php");
   }else{
       //echo 'Data Not Updated';
   }
   mysqli_close($connect);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>

    <link rel="apple-touch-icon" href="assets/img/apple-icon.png">
<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
<!-- Load Require CSS -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<!-- Font CSS -->
<link href="assets/css/boxicon.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/profile.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>
<div class="limiter">
	<div class="redbackground" style="background-image: url('images/red.jpg');">
      <br><br>
      <div style="width: 50%; margin: auto;">
         <div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
            <div class="profile-content">
               <div class="profile-section">
               <form class="form" action="edit.php" method="post">
               <span class="login100-form-title"><?php echo $user_data['user_name']; ?></span><br>
                    
                    <div class="row">
                        <div class="col">
                        <span class="txt2"><strong>Name:</strong></span>
                            <input class="form-control" type="text" name="fullName" value="<?php echo $user_data['fullName']; ?>">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col">
                        <span class="txt2"><strong>Email:</strong></span>
                            <input class="form-control" type="text" name="userEmail" value="<?php echo $user_data['userEmail']; ?>">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col">
                        <span class="txt2"><strong>About Me:</strong></span>
                            <input class="form-control" type="text" name="userBio" value="<?php echo $user_data['userBio']; ?>">
                        </div>
                    </div>   
                    <br>                                  
                    <div class="row">
                        <div class="col d-flex justify-content-end">
                            <input class="btn btn-primary" type="submit" name="update" value="Update Data">
                        </div>
                    </div>                         
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
                                <!-- Bootstrap -->
                                <script src="assets/js/bootstrap.bundle.min.js"></script>
                                <!-- Templatemo -->
                                <script src="assets/js/templatemo.js"></script>
                                <!-- Custom -->
                                <script src="assets/js/custom.js"></script>

</body>

</html>
