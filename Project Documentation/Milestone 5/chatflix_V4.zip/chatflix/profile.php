<?php 
session_start();

	include("connection.php");
	include("functions.php");
   include("navbar.php");
	$user_data = check_login($con);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>

    <link rel="apple-touch-icon" href="assets/img/apple-icon.png">
<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
<!-- Load Require CSS -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<!-- Font CSS -->
<link href="assets/css/boxicon.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/profile.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">

</head>

<body>
<div class="limiter">
	<div class="redbackground" style="background-image: url('images/red.jpg');">
      <br><br>
      <div style="width: 50%; margin: 0 auto;">
         <div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
            <div class="profile-content">
               <div class="profile-section">
                  <span class="login100-form-title"><?php echo $user_data['user_name']; ?></span><br>
                  <span class="txt2"><strong>Name:</strong> <br></span><spam style="input100"><?php echo $user_data['fullName']; ?></span><br><br>
                  <span class="txt2"><strong>About Me:</strong> <br></span><spam style="input100"><?php echo $user_data['userBio']?></span><br><br>
                  <p><span>Date Joined: <?php echo $user_data['date']; ?></span></p><br>
               </div>
            </div>
         </div>
         <br>  
         <div class="col d-flex justify-content-start" style="width: 50%; margin: 0 auto;">
            <a class="nav-link btn-primary rounded-pill px-3" href="/chatflix/edit.php">Edit Profile</a>
         </div>
      </div>
   </div>
</div>

    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Templatemo -->
    <script src="assets/js/templatemo.js"></script>
    <!-- Custom -->
    <script src="assets/js/custom.js"></script>
</body>
</html>