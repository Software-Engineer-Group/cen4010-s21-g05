<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<link rel="stylesheet" type="text/css" href="css/series.css">

<div class="limiter">
		<div class="redbackground" style="background-image: url('images/red.jpg');">

<div class="container bootstrap snippets bootdey">
    <div class="profile card">
        <div class="profile-body">
            <div class="profile-bio">
                <div class="row">
                    <div class="col-md-5 text-center">
                        <img class="img-thumbnail md-margin-bottom-10" src="images/spirited.jpg" alt="series photo">
                    </div>

                        <div class="col-md-7">  
                           <h3>Spirited Away</h3>
                            <hr>
                            <p>The story is about the adventures of a young ten-year-old girl named Chihiro as she wanders into the world of the gods and spirits.
                               She is forced to work at a bathhouse following her parents being turned into pigs by the witch Yubaba.</p>
                            <hr>
                            <a class="nav-link btn-outline-primary rounded-pill px-3" style="margin: top -100px;"  href="discussion.php">Discussion</a>
                     </div>
                  </div>    
               </div>
        	</div>
              <div class="iframe-container">
              <iframe width="560" height="315" src="https://www.youtube.com/embed/ByXuk9QqQkk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>            </div>
        </div>
     </div>   
    </div>
</div>                             