<?php

	include("connection.php");
	include("functions.php");

	$user_data = check_login($con);



// Escape user inputs for security
$fullName = mysqli_real_escape_string($con, $_REQUEST["fullName"]);
//$email = mysqli_real_escape_string($link, $_REQUEST['email']);
 
// Attempt insert query execution
$sql = "INSERT INTO defaultuser (fullName) VALUES ('$fullName')";


?>