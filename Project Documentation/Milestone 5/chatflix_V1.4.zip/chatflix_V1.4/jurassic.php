<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<link rel="stylesheet" type="text/css" href="css/series.css">

<body>
<div class="container bootstrap snippets bootdey">
    <div class="profile card">
        <div class="profile-body">
            <div class="profile-bio">
                <div class="row">
                    <div class="col-md-5 text-center">
                        <img class="img-thumbnail md-margin-bottom-10" src="images/jurassic.jpg" alt="">
                    </div>
                    <div class="col-md-7">
                    <a class="nav-link btn-outline-primary rounded-pill px-3" id="navbar" href="discussion.php">Jurassic Park</a>
                        <hr>
                        <p>Wealthy businessman John Hammond and a team of genetic scientists have created a wildlife park of de-extinct dinosaurs.</p>
                        <p>When industrial sabotage leads to a catastrophic shutdown of the park's power facilities and security precautions, a small group of visitors and Hammond's grandchildren struggle to survive and escape the perilous island.</p>
                    </div>
                </div>    
            </div>
    	</div>
    </div>
</div>  
        <!-- Bootstrap -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Templatemo -->
    <script src="assets/js/templatemo.js"></script>
    <!-- Custom -->
    <script src="assets/js/custom.js"></script>
</body>