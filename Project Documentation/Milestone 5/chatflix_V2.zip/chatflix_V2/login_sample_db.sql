-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2021 at 02:16 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_sample_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `defaultuser`
--

CREATE TABLE `defaultuser` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(256) NOT NULL,
  `avatar_id` int(11) DEFAULT NULL,
  `fullName` varchar(20) DEFAULT NULL,
  `dateJoined` varchar(10) DEFAULT NULL,
  `userEmail` varchar(25) DEFAULT NULL,
  `activityStatus` int(11) DEFAULT NULL,
  `privacySet` int(11) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `userBio` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `defaultuser`
--

INSERT INTO `defaultuser` (`id`, `user_id`, `user_name`, `password`, `avatar_id`, `fullName`, `dateJoined`, `userEmail`, `activityStatus`, `privacySet`, `date`, `userBio`) VALUES
(1, 235125794241, 'jabdool2016', 'abdool22', NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-07 21:49:54', NULL),
(6, 8605086619, 'test123', '123', 3, 'wefewfwe', '', 'wefwefwe', 0, 0, '2021-04-07 19:18:53', NULL),
(7, 0, '', '', NULL, '', NULL, NULL, NULL, NULL, '2021-04-07 17:28:15', NULL),
(9, 5946914717974223, 'Steven23', '123test', NULL, 'Steven Richards', NULL, 'stevenwonder@gmail.com', NULL, NULL, '2021-04-07 23:17:40', 'Hey I am Steven!'),
(10, 8822702526, 'roland', '$2y$10$aMFq9ILR4pzZB', NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-09 04:27:36', NULL),
(11, 58678065726086233, 'bart', '$2y$10$lLNJS6IbKuVvC', NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-09 04:36:14', NULL),
(12, 73301682, 'bobby', '$2y$10$dcIjiJZtvZyOa', NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-09 04:43:38', NULL),
(13, 94171903322043, 'lilly', '$2y$10$Q4xvRD7ZkqPBdodFAZBMD.5anL33D7HQteUW1td6OJk631Emntbca', NULL, 'q', NULL, 'q', NULL, NULL, '2021-04-09 04:56:25', 'q'),
(14, 26456247, 'john', '$2y$10$pSLjIKjREfuQH8YTS/cF7eNvrZCTFkoHal0QfBQ.4/NLbvL7cuRPu', NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-12 01:21:46', NULL),
(15, 22970, 'smiley', '$2y$10$fzFWfNdWTh2MDoTEIyWNauaVgVGHEnOYZAyWMlZl96m7wPScRS04a', NULL, '\"', NULL, '\"', NULL, NULL, '2021-04-16 16:03:15', '\"'),
(16, 163446960071774021, 'flaffy88', '$2y$10$EJL4vAjcQKjvTNVMk3RKNOfEdCyfAJj/u6nkzWdeD0/Cv7yruyw.y', NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-14 02:10:16', NULL),
(17, 7221, 'happy123', '$2y$10$e6W1NJM7KTfbdf/QsNyK8OzfnCEhroHJv9bvVJ71jEQt/rV6Q7/Ei', NULL, 'dtyj', NULL, 'wsryh', NULL, NULL, '2021-04-14 02:22:06', 'hxdn'),
(18, 99480485069824, 'iglooice7', '$2y$10$3XQ4E0Nl.I4ix5nb3RjzU.DP2zhUnJhz82qtv.0aw1MDhf7s83xWO', NULL, 'df', NULL, 'ssg', NULL, NULL, '2021-04-14 02:35:49', 'thaet'),
(19, 674131830196282, 'flower55', '$2y$10$3Q0sq7tPGi4ghD0lHTR3iuBXBv11wj0RH8BlUinXeHJ6rY.0fvFSa', NULL, 'Daisy Arta', NULL, 'hi@hello.com', NULL, NULL, '2021-04-14 02:38:56', 'hi!');

-- --------------------------------------------------------

--
-- Table structure for table `discgenre`
--

CREATE TABLE `discgenre` (
  `gid` int(11) NOT NULL,
  `genreTitle` varchar(100) NOT NULL,
  `genreDesc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `discgenre`
--

INSERT INTO `discgenre` (`gid`, `genreTitle`, `genreDesc`) VALUES
(1, 'TV Series', 'Talk about the TV shows you are watching'),
(2, 'Movies', 'Talk about the movies you have watched here.');

-- --------------------------------------------------------

--
-- Table structure for table `discpost`
--

CREATE TABLE `discpost` (
  `threadId` int(11) NOT NULL,
  `avatar_id` int(11) NOT NULL,
  `userName` varchar(20) NOT NULL,
  `postCont` varchar(2000) DEFAULT NULL,
  `gid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discpost`
--

INSERT INTO `discpost` (`threadId`, `avatar_id`, `userName`, `postCont`, `gid`) VALUES
(0, 0, 'smiley', 'thread description #1', 1),
(0, 0, 'smiley', 'reply to first thread', 1),
(2147483647, 0, 'smiley', 'description for second thread', 1),
(570831652, 0, 'smiley', 'description for third thread topic', 1);

-- --------------------------------------------------------

--
-- Table structure for table `discthread`
--

CREATE TABLE `discthread` (
  `threadId` int(11) NOT NULL,
  `threadTopic` varchar(200) DEFAULT NULL,
  `gid` int(11) NOT NULL,
  `threadKeyword` varchar(100) NOT NULL,
  `threadContent` varchar(2000) NOT NULL,
  `userId` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discthread`
--

INSERT INTO `discthread` (`threadId`, `threadTopic`, `gid`, `threadKeyword`, `threadContent`, `userId`) VALUES
(0, 'First thread topic', 1, 'grays', 'thread description #1', 0),
(2147483647, 'second thread topic', 1, 'grays', 'description for second thread', 0),
(570831652, 'Third thread topic', 1, 'grays', 'description for third thread topic', 0);

-- --------------------------------------------------------

--
-- Table structure for table `friendlist`
--

CREATE TABLE `friendlist` (
  `user_id` int(11) NOT NULL,
  `avatar_id` int(11) NOT NULL,
  `userName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `moduser`
--

CREATE TABLE `moduser` (
  `id` int(11) NOT NULL,
  `completed` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `seriespg`
--

CREATE TABLE `seriespg` (
  `seriesId` int(11) NOT NULL,
  `seriesSeasons` int(11) DEFAULT NULL,
  `seriesName` varchar(20) NOT NULL,
  `seriesBio` varchar(2000) DEFAULT NULL,
  `seriesKeywords` varchar(256) NOT NULL,
  `seriesLink` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `seriespg`
--

INSERT INTO `seriespg` (`seriesId`, `seriesSeasons`, `seriesName`, `seriesBio`, `seriesKeywords`, `seriesLink`) VALUES
(2, NULL, 'Grey\'s Anatomy', 'Meredith Grey and friends learn how to do doctor stuff.', 'grey g grey\'s grey anatomy gray grays gray\'s ', 'http://localhost/chatflix/greys.php'),
(3, NULL, 'Guardians of the Gal', 'A band of intergalactic outlaws who teamed together to protect the galaxy from planetary threats.', 'g gu gua guard guardian guardians gala galaxy of the', 'http://localhost/chatflix/guardians.php'),
(4, NULL, 'Spirited Away', 'A 10-year-old girl who, while moving to a new neighborhood, enters the world of spirits.', 's spir spirit spirited aw away', 'http://localhost/chatflix/spirited.php'),
(5, NULL, 'Jurassic Park', 'Scientists visiting a safari amusement park of genetically engineered dinosaurs on an island over one weekend.', 'j jur juras jurasic jurassic pa par park', 'http://localhost/chatflix/jurassic.php'),
(6, NULL, 'Forrest Gump', 'The story of a man whose slow-wittedness doesn\'t hold him back.', 'f for forr forrest gu gum gump', 'http://localhost/chatflix/forrest.php'),
(7, NULL, 'Friends', 'Three young men and three young women live in the same apartment complex and face life and love in New York.', 'f fr fri friend friends', 'http://localhost/chatflix/friend.php'),
(8, NULL, 'Parks and Recreation', 'A story that revolves around Leslie Knope, the deputy director of the parks and recreation department in the fictional Indiana town of Pawnee.', 'p par park parks and r re recre recrea recreat recreation ', 'http://localhost/chatflix/parks.php'),
(9, NULL, 'Game of Thrones', 'Nine noble families fight for control of the mythical land of Westeros.', 'g ga game of th thr thro thron thrones', 'http://localhost/chatflix/got.php');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(256) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_id`, `user_name`, `password`, `date`) VALUES
(1, 7078920729727274, 'Monica', 'Silvestri', '2021-03-27 17:46:21'),
(2, 2053, 'Mary', 'Poppins', '2021-03-27 17:47:11'),
(4, 2270883332, 'Meredith', 'Grey123', '2021-03-27 23:14:01'),
(5, 401915787336, 'Mary', 'Poppins', '2021-03-31 16:08:51'),
(6, 82289744876, 'Mary', 'Poppins', '2021-04-04 13:40:08'),
(7, 6266394045, 'phil', 'spinach', '2021-04-09 00:58:01'),
(8, 8038551585, 'moira', '$2y$10$hDMCZJEey3dHz48IVM51zuUGjxuySGHU8TcIVkaDUZ8UBLLrm5O.u', '2021-04-09 00:59:22'),
(9, 50398731629639062, 'lisa', '$2y$10$bgjMS8lzhsTEZSFitraOP.q7MzmLk6.qQ5O7muju3dPDYb8SoKwuy', '2021-04-09 03:02:01'),
(10, 4706860514, 'user', '$2y$10$d1FmP4KhCMtF6p5pir3VQuEn9urz1i5GxiJDd/sSqE3iMMe2hQIiO', '2021-04-09 03:34:54'),
(11, 2871, 'johnny', '$2y$10$X9CMf9lm9ziAZkCNxqiXg.8tcAXWgKJtZCE55zsg40SFUDV20khGC', '2021-04-09 03:58:43'),
(12, 5826, 'belinda', '$2y$10$8ePXqFoPDjB4loJ46shCa.Fm0DvkO9HaYBBAcxqfIMhsKUwBpd8Xm', '2021-04-09 04:11:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `defaultuser`
--
ALTER TABLE `defaultuser`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_name` (`user_name`),
  ADD UNIQUE KEY `avatarId` (`avatar_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `date` (`date`) USING BTREE;

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `date` (`date`),
  ADD KEY `user_name` (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `defaultuser`
--
ALTER TABLE `defaultuser`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
