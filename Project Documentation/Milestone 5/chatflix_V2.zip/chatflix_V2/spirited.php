<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<link rel="stylesheet" type="text/css" href="css/series.css">


<div class="container bootstrap snippets bootdey">
    <div class="profile card">
        <div class="profile-body">
            <div class="profile-bio">
                <div class="row">
                    <div class="col-md-5 text-center">
                        <img class="img-thumbnail md-margin-bottom-10" src="images/spirited.jpg" alt="">
                    </div>
                    <div class="col-md-7">
                    <a class="nav-link btn-outline-primary rounded-pill px-3" id="navbar" href="discussion.php">Spirited Away</a>
                        <hr>
                        <p>The story is about the adventures of a young ten-year-old girl named Chihiro as she wanders into the world of the gods and spirits.</p>
                        <p>She is forced to work at a bathhouse following her parents being turned into pigs by the witch Yubaba.</p>
                    </div>
                </div>    
            </div>
    	</div>
    </div>
</div>                             