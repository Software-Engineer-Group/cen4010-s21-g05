<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<link rel="stylesheet" type="text/css" href="css/series.css">

<div class="limiter">
		<div class="redbackground" style="background-image: url('images/red.jpg');">

<div class="container bootstrap snippets bootdey">
    <div class="profile card">
        <div class="profile-body">
            <div class="profile-bio">
                <div class="row">
                    <div class="col-md-5 text-center">
                        <img class="img-thumbnail md-margin-bottom-10" src="images/greys.jpg" alt="series photo">
                    </div>

                        <div class="col-md-7">  
                           <h3>Grey's Anatomy</h3>
                            <hr>
                            <p>A drama centered on the personal and professional lives of five surgical interns and their supervisors. A medical based drama centered around Meredith Grey, an aspiring surgeon and daughter of one of the best surgeons, Dr. Ellis Grey.</p>
                           <hr>
                            <a class="nav-link btn-outline-primary rounded-pill px-3" style="margin: top -100px;"  href="discussion.php">Discussion</a>
                     </div>
                  </div>    
               </div>
        	</div>
              <div class="iframe-container">
                  <iframe width="560" height="315" src="https://www.youtube.com/embed/q1pcpgREQ5c" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
        </div>
     </div>   
    </div>
</div>                             