<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<link rel="stylesheet" type="text/css" href="css/series.css">

<div class="limiter">
	<div class="redbackground" style="background-image: url('images/red.jpg');">
        <div class="container bootstrap snippets bootdey">
            <div class="profile card">
                <div class="profile-body">
                    <div class="profile-bio">
                        <div class="row">
                            <div class="col-md-5 text-center">
                                <img class="img-thumbnail md-margin-bottom-10" src="images/guardians.jpg" alt="">
                            </div>
                            <div class="col-md-7">
                            <h3>Guardians of the Galaxy</h3>
                                <hr>
                                <p>Brash space adventurer Peter Quill (Chris Pratt) finds himself the quarry of relentless bounty hunters after he steals an orb coveted by Ronan, a powerful villain</p>
                                <p>To evade Ronan, Quill is forced into an uneasy truce with four disparate misfits: gun-toting Rocket Raccoon, treelike-humanoid Groot, enigmatic Gamora, and vengeance-driven Drax the Destroyer.</p>
                                <hr>
                                <a class="nav-link btn-outline-primary rounded-pill px-3" style="margin: top -100px;"  href="discussion.php">Discussion</a>
                            </div>
                        </div>    
                    </div>
                </div>
                <div class="iframe-container">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/d96cjJhvlMA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>            </div>
            </div>
        </div>
    </div>
</div>                             