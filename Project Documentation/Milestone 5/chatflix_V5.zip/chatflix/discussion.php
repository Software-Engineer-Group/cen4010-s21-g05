<?php
session_start();

include("connection.php");
include("functions.php");
include("header.php");
$user_data = check_login($con);

?>

<!DOCTYPE html>
<html>

<head>
    <title>Chatflix</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="assets/img/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    <!-- Load Require CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font CSS -->
    <link href="assets/css/boxicon.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,800" rel="stylesheet" />
    <!-- Load Tempalte CSS -->
    <link rel="stylesheet" href="assets/css/templatemo.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="css/discussion.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>
    <div class="limiter">
		<div class="redbackground" style="background-image: url('images/red.jpg');">

            <br><br>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="wrapper wrapper-content animated fadeInRight">
                            <div class="p-xs">
                                <h1>Chatflix Forum</h1>
                            </div>
                        </div>
                        <div class="forum-title">
                            <h4>Choose a Category</h4>
                        </div>
                        <div class='forum-item'>
                            <?php
                            include("connection.php");
                                
                            // Creating an sql query composed of all the genres with tiles in ascending order
                            $sql = "SELECT * FROM discgenre ORDER BY genreTitle ASC";
                            $res = mysqli_query($con,$sql) or die(mysqli_error());
                                
                            // Genres variable is it to blank so each different row qurey from the sql table can be 
                            // appeneded to the variable and outputed all at once at the end of runtime.
                            $genres = "";
                                
                            // While there are still rows that have information about a unique genre it will set php
                            // variables to sql data values and inject those variables into the hmtl template for genres listed
                            if (mysqli_num_rows($res) > 0) 
                            {
                                while($row = mysqli_fetch_assoc($res))
                                {
                                    $gid = $row['gid'];
                                    $genreTitle = $row['genreTitle'];
                                    $genreDesc = $row['genreDesc'];
                                    // $genres .= "
                                    // <div class='forum-title'><a href='view_discGenre.php?gid=".$gid."' class='forum-item-title'>$genreTitle</a></div>
                                    // <div class='forum-sub-title'>$genreDesc</div>
                                    // ";
                                    echo "
                                    <div class='ibox-content'>
                                    <a href='view_discGenre.php?gid=".$gid."' class='forum-item-title'>$genreTitle</a>
                                    <div class='forum-sub-title'>$genreDesc</div>
                                    </div>
                                    ";
                                 }
                              }
                              else{
                                    // Incase of error where no genres exist yet this echo statement notifies the user
                                    echo "
                                    <div class='ibox-content'>
                                    <div class='forum-title'><a href='view_discGenre.php?gid=".$gid."' class='forum-item-title'>$genreTitle</a></div>
                                    <div class='forum-sub-title'>No vategories are available.</div>
                                    </div>
                                    ";
                                }
                              ?>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Templatemo -->
    <script src="assets/js/templatemo.js"></script>
    <!-- Custom -->
    <script src="assets/js/custom.js"></script>

</body>

</html>
