<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<link rel="stylesheet" type="text/css" href="css/series.css">

<body>
<div class="container bootstrap snippets bootdey">
    <div class="profile card">
        <div class="profile-body">
            <div class="profile-bio">
                <div class="row">
                    <div class="col-md-5 text-center">
                        <img class="img-thumbnail md-margin-bottom-10" src="images/friends.jpg" alt="">
                    </div>
                    <div class="col-md-7">
                    <a class="nav-link btn-outline-primary rounded-pill px-3" id="navbar" href="discussion.php">Friends</a>
                        <hr>
                        <p>Three young men and three young women live in the same apartment complex and face life and love in New York. </p>
                        <p>They're not above sticking their noses into one another's business and swapping romantic partners, which always leads to the kind of hilarity average people will never experience - especially during breakups.</p>
                    </div>
                </div>    
            </div>
    	</div>
    </div>
</div>     
        <!-- Bootstrap -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Templatemo -->
    <script src="assets/js/templatemo.js"></script>
    <!-- Custom -->
    <script src="assets/js/custom.js"></script>
</body>