<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<link rel="stylesheet" type="text/css" href="css/series.css">

<body>
<div class="container bootstrap snippets bootdey">
    <div class="profile card">
        <div class="profile-body">
            <div class="profile-bio">
                <div class="row">
                    <div class="col-md-5 text-center">
                        <img class="img-thumbnail md-margin-bottom-10" src="images/parks.jpg" alt="">
                    </div>
                    <div class="col-md-7">
                    <a class="nav-link btn-outline-primary rounded-pill px-3" id="navbar" href="discussion.php">Parks and Recreation</a>
                        <hr>
                        <p>For years Leslie Knope has labored as a small-town, mid-level bureaucrat in the Parks and Recreation department of Pawnee, Ind.
                        It’s a lowly station for one who once held hopes of becoming the country’s first female president. But does that dampen her enthusiasm? Hardly.
                        </p>
                        
                    </div>
                </div>    
            </div>
    	</div>
    </div>
</div>                             

    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Templatemo -->
    <script src="assets/js/templatemo.js"></script>
    <!-- Custom -->
    <script src="assets/js/custom.js"></script>
</body>