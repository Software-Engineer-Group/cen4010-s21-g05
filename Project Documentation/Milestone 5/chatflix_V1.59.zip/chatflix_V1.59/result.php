<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>


<!DOCTYPE html> 
<html> 
	<head>
		
<style type="text/css">
.results {margin-left:12%; margin-right:12%; margin-top:80px;}
</style>
	<h1>Search Results</h1>
	</head> 

<?php 
	
	if(isset($_GET['search'])){
	
	$get_value = $_GET['user_query'];
	
	if($get_value==''){
	
	echo "<center><b>Please go back and enter something into the search box.</b></center>";
	exit();
	}
	
	$result_query = "select * from seriespg where seriesKeywords like '%$get_value%'";
	$thread_result = "select * from discthread where threadKeyword like '%$get_value%'";
	

	$run_result = mysqli_query($con, $result_query);
	$result2 = mysqli_query($con, $thread_result);
	
	if(mysqli_num_rows($run_result)<1  && mysqli_num_rows($result2)<1){
	
	echo "<center><b>No results found. Please try again.</b></center>";
	exit();
	
	}
	
	while($row_result=mysqli_fetch_array($run_result)){
		
		$seriesName=$row_result['seriesName'];
		$seriesLink=$row_result['seriesLink'];
		$seriesBio=$row_result['seriesBio'];
	
	echo "<div class='results'>
		
		<a href='$seriesLink'>$seriesName</a>
		<p align='justify'>$seriesBio</p> 
		
		</div>";

		}

	while($row_result=mysqli_fetch_array($result2)){
		
		$threadTopic=$row_result['threadTopic'];
		$getThreadID = $row_result['threadId'];
		$getGenreID = $row_result['gid'];
		//$threadLink=$row_result['seriesLink'];
		//$seriesBio=$row_result['seriesBio'];
		
	echo "<div class='results'>

		<a href='http://localhost/chatflix/view_discThread.php?gid=$getGenreID&threadId=$getThreadID'>$threadTopic</a>
			
		</div>";
	
		}
}


?>


</body> 
</html>