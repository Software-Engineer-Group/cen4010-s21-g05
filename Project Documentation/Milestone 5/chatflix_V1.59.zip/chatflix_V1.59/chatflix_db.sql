CREATE DATABASE chatflix_db;
-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2021 at 02:18 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatflix_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `defaultuser`
--

CREATE TABLE `defaultuser` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `avatar_id` int(11) DEFAULT NULL,
  `fullName` varchar(20) DEFAULT NULL,
  `dateJoined` varchar(10) DEFAULT NULL,
  `userEmail` varchar(25) DEFAULT NULL,
  `activityStatus` int(11) DEFAULT NULL,
  `privacySet` int(11) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `userBio` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `defaultuser`
--

INSERT INTO `defaultuser` (`id`, `user_id`, `user_name`, `password`, `avatar_id`, `fullName`, `dateJoined`, `userEmail`, `activityStatus`, `privacySet`, `date`, `userBio`) VALUES
(1, 235125794241, 'jabdool2016', 'abdool22', NULL, NULL, NULL, NULL, NULL, NULL, '2021-04-07 21:49:54', NULL),
(6, 8605086619, 'test123', '123', 3, 'wefewfwe', '', 'wefwefwe', 0, 0, '2021-04-07 19:18:53', NULL),
(7, 0, '', '', NULL, '', NULL, NULL, NULL, NULL, '2021-04-07 17:28:15', NULL),
(9, 5946914717974223, 'Steven23', '123test', NULL, 'Steven Richards', NULL, 'stevenwonder@gmail.com', NULL, NULL, '2021-04-07 23:17:40', 'Hey I am Steven!');

-- --------------------------------------------------------

--
-- Table structure for table `discpost`
--

CREATE TABLE `discpost` (
  `postId` int(11) NOT NULL,
  `threadId` int(11) NOT NULL,
  `avatar_id` int(11) NOT NULL,
  `userName` varchar(20) NOT NULL,
  `postCont` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `discthread`
--

CREATE TABLE `discthread` (
  `threadId` int(11) NOT NULL,
  `threadTopic` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `friendlist`
--

CREATE TABLE `friendlist` (
  `user_id` int(11) NOT NULL,
  `avatar_id` int(11) NOT NULL,
  `userName` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `moduser`
--

CREATE TABLE `moduser` (
  `id` int(11) NOT NULL,
  `completed` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `seriespg`
--

CREATE TABLE `seriespg` (
  `seriesId` int(11) NOT NULL,
  `seriesSeasons` int(11) DEFAULT NULL,
  `seriesImg` int(11) NOT NULL,
  `seriesName` varchar(20) NOT NULL,
  `seriesBio` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `defaultuser`
--
ALTER TABLE `defaultuser`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_name` (`user_name`),
  ADD UNIQUE KEY `avatarId` (`avatar_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `date` (`date`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `defaultuser`
--
ALTER TABLE `defaultuser`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
