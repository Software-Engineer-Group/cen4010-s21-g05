<?php 
session_start();

	include("../connection.php");
	include("../functions.php");
    include("../header.php");

	$user_data = check_login($con);

?>



<!DOCTYPE html>
<html>
<head>
	<title>Chatflix</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="../assets/img/apple-icon.png">
    <link rel="shortcut icon" type="image/x-icon" href="../assets/img/favicon.ico">
    <!-- Load Require CSS -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font CSS -->
    <link href="../assets/css/boxicon.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Load Tempalte CSS -->
    <link rel="stylesheet" href="../assets/css/templatemo.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/custom.css">
	<link rel="stylesheet" href="../css/discussion.css">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>

<?php include("../navbar.php");?>

<br><br><div class="container">
<div class="row">
    <div class="col-lg-12">
        <div class="wrapper wrapper-content animated fadeInRight">

            <div class="ibox-content m-b-sm border-bottom">
                <div class="p-xs">
                    <div class="pull-left m-r-md">
                    </div>
                    <h2>Chatflix Forums</h2>
                </div>
            </div>

            <div class="ibox-content forum-container">

                <div class="forum-title">
                    <div class="pull-right forum-desc">
                        <samll>Total posts: 320,800</samll>
                    </div>
                    <h3>Action</h3>
                </div>

                <div class="forum-item">
                    <div class="row">
                        <div class="col-md-9">
                            <div class="forum-icon">
                                <i class="fa fa-clock-o"></i>
                            </div>
                            <a href="../posts.php" class="forum-item-title">Action </a>
                            <div class="forum-sub-title">Various versions have evolved over the years, sometimes by accident, sometimes on purpose passage of Lorem Ipsum (injected humour and the like).</div>
                        </div>
                        <div class="col-md-1 forum-info">
                            <span class="views-number">
                                1516
                            </span>
                            <div>
                                <small>Views</small>
                            </div>
                        </div>
                        <div class="col-md-1 forum-info">
                            <span class="views-number">
                                238
                            </span>
                            <div>
                                <small>Topics</small>
                            </div>
                        </div>
                        <div class="col-md-1 forum-info">
                            <span class="views-number">
                                180
                            </span>
                            <div>
                                <small>Posts</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
        <!-- Bootstrap -->
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
    <!-- Templatemo -->
    <script src="../assets/js/templatemo.js"></script>
    <!-- Custom -->
    <script src="../assets/js/custom.js"></script>
    </body>
    
<?php 
   $hostname = "localhost";
   $username = "root";
   $password = "";
   $databaseName = "chatflix_db";
   
   $connect = mysqli_connect($hostname, $username, $password, $databaseName);

	
$result_query = "select * from discthread where genre like 'action'";

$run_result = mysqli_query($connect, $result_query);
 echo "$run_result";
    


echo "<center><b>No results found. Please try again.</b></center>";
exit();







?>