<nav id="main_nav" class="navbar navbar-expand-lg navbar-light bg-white shadow">
<link rel="stylesheet" type="text/css" href="css/main.css">

        <div class="container d-flex justify-content-between align-items-center">
            <a class="navbar-brand h1" href="index.php">
               
                <span class="text-dark h4"><img src="chatflixlogo.nav.jpg" alt="chatflix logo" style="width:40%; margin-bottom: -8px; margin-left:50px; margin-right:-600px;" ></span>
            </a>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-toggler-success" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="align-self-center collapse navbar-collapse flex-fill  d-lg-flex justify-content-lg-between" id="navbar-toggler-success" style>
                <div class="flex-fill mx-xl-5 mb-2">
                    <ul class="nav navbar-nav d-flex justify-content-between mx-xl-5 text-center text-dark">
                        <li class="nav-item">
                            <a class="nav-link btn-outline-primary rounded-pill px-3" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn-outline-primary rounded-pill px-3" href="profile.php">Profile</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn-outline-primary rounded-pill px-3" href="discussion.php">Forum</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link btn-outline-primary rounded-pill px-3" href="search.php">Search</a>
                        </li>
						<li class="nav-item">
                            <a class="nav-link btn-outline-primary rounded-pill px-3" id="navbar" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
                <div class="navbar align-self-center d-flex"> 
                </div>
            </div>
        </div>
    </nav>
