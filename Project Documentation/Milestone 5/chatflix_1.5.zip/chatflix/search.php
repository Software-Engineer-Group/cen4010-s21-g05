<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<style type="text/css">

	form {
	margin:25%;
	}

</style>
	
<head>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</head>	
<body> 
	<form action="result.php" method="get"> 

		<input type="text" name="user_query" size="80" placeholder="Search for Movie or TV Show"/> 
		<input type="submit" name="search" value="Search">		
	
	</form>

    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Templatemo -->
    <script src="assets/js/templatemo.js"></script>
    <!-- Custom -->
    <script src="assets/js/custom.js"></script>
</body>
</html>