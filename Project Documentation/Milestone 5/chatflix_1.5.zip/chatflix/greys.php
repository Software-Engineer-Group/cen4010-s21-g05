<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>

<link rel="stylesheet" type="text/css" href="css/series.css">

<body>
<div class="container bootstrap snippets bootdey">
    <div class="profile card">
        <div class="profile-body">
            <div class="profile-bio">
                <div class="row">
                    <div class="col-md-5 text-center">
                        <img class="img-thumbnail md-margin-bottom-10" src="images/greys.jpg" alt="">
                    </div>
                    <div class="col-md-7">
                    <a class="nav-link btn-outline-primary rounded-pill px-3" id="navbar" href="discussion.php">Grey's Anatomy</a>
                        <hr>
                        
                        <p>A drama centered on the personal and professional lives of five surgical interns and their supervisors.</p>
                        <p>A medical based drama centered around Meredith Grey, an aspiring surgeon and daughter of one of the best surgeons, Dr. Ellis Grey.</p>

                    </div>
                </div>    
            </div>
    	</div>
    </div>
</div>  
    
        <!-- Bootstrap -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Templatemo -->
    <script src="assets/js/templatemo.js"></script>
    <!-- Custom -->
    <script src="assets/js/custom.js"></script>
</body>