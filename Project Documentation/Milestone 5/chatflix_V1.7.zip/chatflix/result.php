<?php 
session_start();

	include("connection.php");
	include("functions.php");
    include("header.php");

	$user_data = check_login($con);

?>


<!DOCTYPE html> 
<html> 
<head>
<link href="https://fonts.googleapis.com/css?family=Poppins:400,800" rel="stylesheet" />
<link rel="stylesheet" href="css/results.css">


</head> 
<body>
<div class="limiter">
		<div class="redbackground" style="background-image: url('images/red.jpg');">
			

<?php 
	
	if(isset($_GET['search'])){
	
	$get_value = $_GET['user_query'];
	
	if($get_value==''){
	
	echo "<center><b style='color:white;' >Please go back and enter something into the search box.</b></center>";
	exit();
	}
	
	$result_query = "select * from seriespg where seriesKeywords like '%$get_value%'";
	$thread_result = "select * from discthread where threadKeyword like '%$get_value%'";
	

	$run_result = mysqli_query($con, $result_query);
	$result2 = mysqli_query($con, $thread_result);
	
	if(mysqli_num_rows($run_result)<1  && mysqli_num_rows($result2)<1){
	
	echo "<center><b style='color:white;'>No results found. Please try again.</b></center>";
	exit();
	
	}
	echo "<center><h2>Catalog Results</h2></center>";
	while($row_result=mysqli_fetch_array($run_result)){
		
		$seriesName=$row_result['seriesName'];
		$seriesLink=$row_result['seriesLink'];
		$seriesBio=$row_result['seriesBio'];
	
	echo "<div class='results'>
		<div class='profile-body'>
		<div class='profile card'>		
		<p align='justify'>	<a class='series' href='$seriesLink'>$seriesName</a></p>
		<p align='justify'>$seriesBio</p> 
		
		</div>";

		}

	echo "<h2>Forum Results</h2>";	
	while($row_result=mysqli_fetch_array($result2)){
		
		$threadTopic=$row_result['threadTopic'];
		$getThreadID = $row_result['threadId'];
		$getGenreID = $row_result['gid'];
		//$threadLink=$row_result['seriesLink'];
		//$seriesBio=$row_result['seriesBio'];
		
	echo "<div class='results'>


        <div class='profile-body'>
		<div class='profile card'>
		<p align='justify'>	<a class='series' href='http://localhost/chatflix/view_discThread.php?gid=$getGenreID&threadId=$getThreadID'>$threadTopic</a></p>
		</div>
		</div>";
			
		}
}


?>


</body> 
</html>